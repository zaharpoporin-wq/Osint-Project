#!/usr/bin/env bash
# Установка для Mac / Linux. Запуск: bash install.sh
set -e
cd "$(dirname "$0")"

PY="$(command -v python3 || command -v python || true)"
if [ -z "$PY" ]; then
  echo "Python не найден. Установите Python 3 (https://www.python.org/downloads/)."
  exit 1
fi
echo "Найден Python: $("$PY" --version)"

echo "[1/5] Создаю отдельное окружение .venv в папке проекта..."
[ -x .venv/bin/python ] || "$PY" -m venv .venv
VPY=.venv/bin/python
"$VPY" -m pip install --upgrade pip >/dev/null

echo "[2/5] Ставлю зависимости нашего toolkit..."
"$VPY" -m pip install -r toolkit/requirements.txt

echo "[3/5] Поддержка фото HEIC с iPhone..."
"$VPY" -m pip install pillow-heif || echo "   Не встало - не страшно, JPG/PNG работают и без этого."

echo "[4/6] Ставлю Sherlock (поиск по нику)..."
"$VPY" -m pip install ./sherlock

echo "[5/6] Ставлю Holehe (поиск по почте)..."
"$VPY" -m pip install ./holehe || echo "   Holehe не встал - EXIF, Sherlock и HIBP работают и без него."

echo "[6/6] Ставлю SpiderFoot - это дольше всего..."
if ! "$VPY" -m pip install -r spiderfoot/requirements.txt; then
  echo
  echo "   SpiderFoot не установился. Остальное работает и без него."
  echo "   Подробности - в README.md, раздел \"Если SpiderFoot не ставится\"."
fi

echo
echo "Готово. Теперь запускайте: bash start.sh"
