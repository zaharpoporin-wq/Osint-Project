#!/usr/bin/env bash
# Установка для Linux / macOS. Запуск: bash install.sh
set -e
cd "$(dirname "$0")"

say() { printf '%s\n' "$*"; }

# --- 1. Python -------------------------------------------------------------
# SpiderFoot 4.0 рассчитан на Python <= 3.12 (старые lxml/cryptography/networkx),
# поэтому сначала ищем совместимый интерпретатор, и только потом любой python3.
pick_python() {
  for c in python3.12 python3.11 python3.10 python3.9 python3 python; do
    if command -v "$c" >/dev/null 2>&1; then
      if "$c" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
        command -v "$c"
        return 0
      fi
    fi
  done
  return 1
}

SUDO=""
if [ "$(id -u)" -ne 0 ] && command -v sudo >/dev/null 2>&1; then
  SUDO="sudo"
fi

PY="$(pick_python || true)"
if [ -z "$PY" ] && command -v apt-get >/dev/null 2>&1; then
  say "Python 3.9+ не найден — пробую установить через apt..."
  $SUDO apt-get update -qq || true
  $SUDO apt-get install -y -qq python3 python3-venv python3-pip || true
  PY="$(pick_python || true)"
fi
if [ -z "$PY" ]; then
  say "Python 3.9+ не найден. Установите Python 3 (https://www.python.org/downloads/)."
  exit 1
fi
say "Найден Python: $("$PY" --version 2>&1) ($PY)"

# --- 2. venv ---------------------------------------------------------------
ensure_venv() {
  if [ -x .venv/bin/python ] && .venv/bin/python -c "import sys" >/dev/null 2>&1; then
    return 0
  fi
  rm -rf .venv
  if "$PY" -m venv .venv 2>/dev/null; then
    return 0
  fi

  say "Модуль venv недоступен — пробую установить python3-venv..."
  if command -v apt-get >/dev/null 2>&1; then
    $SUDO apt-get update -qq || true
    $SUDO apt-get install -y -qq python3-venv python3-pip || true
    rm -rf .venv
    if "$PY" -m venv .venv 2>/dev/null; then
      return 0
    fi
  fi

  # Последний шанс: venv без pip + get-pip.py
  say "Пробую создать venv без pip и поставить pip вручную..."
  rm -rf .venv
  "$PY" -m venv --without-pip .venv || return 1
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL https://bootstrap.pypa.io/get-pip.py -o /tmp/get-pip.py
  elif command -v wget >/dev/null 2>&1; then
    wget -qO /tmp/get-pip.py https://bootstrap.pypa.io/get-pip.py
  else
    return 1
  fi
  .venv/bin/python /tmp/get-pip.py >/dev/null
}

say "[1/6] Создаю отдельное окружение .venv в папке проекта..."
if ! ensure_venv; then
  say "Не удалось создать .venv."
  say "Debian/Ubuntu: sudo apt install python3-venv python3-pip — и повторите."
  exit 1
fi
VPY=.venv/bin/python
"$VPY" -m pip install --upgrade pip >/dev/null 2>&1 || true

say "[2/6] Ставлю зависимости нашего toolkit..."
"$VPY" -m pip install -r toolkit/requirements.txt

say "[3/6] Поддержка фото HEIC с iPhone..."
"$VPY" -m pip install pillow-heif || say "   Не встало - не страшно, JPG/PNG работают и без этого."

say "[4/6] Ставлю Sherlock (поиск по нику)..."
"$VPY" -m pip install ./sherlock

say "[5/6] Ставлю Holehe (поиск по почте)..."
"$VPY" -m pip install ./holehe || say "   Holehe не встал - EXIF, Sherlock и HIBP работают и без него."

say "[6/6] Ставлю SpiderFoot - это дольше всего..."
if "$VPY" -c 'import sys; raise SystemExit(0 if sys.version_info < (3, 13) else 1)'; then
  if ! "$VPY" -m pip install -r spiderfoot/requirements.txt; then
    say
    say "   SpiderFoot не установился. Остальное работает и без него."
    say "   Подробности - в README.md, раздел \"Если SpiderFoot не ставится\"."
  fi
else
  say "   Python $("$VPY" -c 'import sys; print("%d.%d" % sys.version_info[:2])') не поддерживается SpiderFoot 4.0"
  say "   (нужен Python 3.9-3.12). Пропускаю SpiderFoot, остальное работает."
fi

say
say "Готово. Теперь запускайте: bash start.sh"
