#!/usr/bin/env bash
# Запуск для Mac / Linux: bash start.sh
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  echo "Сначала запустите: bash install.sh  (один раз)"
  exit 1
fi
.venv/bin/python toolkit/report.py "$@"
