#!/usr/bin/env bash
# Запуск для Linux / macOS: bash start.sh
cd "$(dirname "$0")"

if [ ! -x .venv/bin/python ] || ! .venv/bin/python -c "import sys" >/dev/null 2>&1; then
  echo "Окружение .venv не найдено — запускаю установку (один раз)..."
  if ! bash install.sh; then
    echo
    echo "Установка не удалась. Запустите вручную: bash install.sh"
    exit 1
  fi
fi

exec .venv/bin/python toolkit/report.py "$@"
