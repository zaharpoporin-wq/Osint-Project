@echo off
chcp 65001 >nul
cd /d "%~dp0"

if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" toolkit\report.py %*
) else (
  echo Сначала запустите install.bat - один раз.
)
echo.
pause
