@echo off
chcp 65001 >nul
cd /d "%~dp0"

rem --- ищем Python: сначала py-launcher, потом python ---
set "PY="
py -3 --version >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
  python --version >nul 2>nul
  if not errorlevel 1 set "PY=python"
)
if not defined PY goto nopython

echo Найден Python:
%PY% --version
echo.

echo [1/5] Создаю отдельное окружение .venv в папке проекта...
if not exist ".venv\Scripts\python.exe" %PY% -m venv .venv
if errorlevel 1 goto fail
set "VPY=.venv\Scripts\python.exe"
"%VPY%" -m pip install --upgrade pip >nul

echo [2/5] Ставлю зависимости нашего toolkit...
"%VPY%" -m pip install -r toolkit\requirements.txt
if errorlevel 1 goto fail

echo [3/5] Поддержка фото HEIC с iPhone...
"%VPY%" -m pip install pillow-heif
if errorlevel 1 echo    Не встало - не страшно, JPG/PNG работают и без этого.

echo [4/6] Ставлю Sherlock (поиск по нику)...
"%VPY%" -m pip install .\sherlock
if errorlevel 1 goto fail

echo [5/6] Ставлю Holehe (поиск по почте)...
"%VPY%" -m pip install .\holehe
if errorlevel 1 echo    Holehe не встал - остальное работает и без него.

echo [6/6] Ставлю SpiderFoot - это дольше всего...
"%VPY%" -m pip install -r spiderfoot\requirements.txt
if errorlevel 1 (
  echo.
  echo    SpiderFoot не установился. Остальное работает и без него.
  echo    Подробности - в README.md, раздел "Если SpiderFoot не ставится".
)

echo.
echo ==============================================
echo   Готово. Теперь запускайте start.bat
echo ==============================================
pause
exit /b 0

:nopython
echo Python не найден.
echo Скачайте его с https://www.python.org/downloads/
echo При установке ОБЯЗАТЕЛЬНО поставьте галочку "Add python.exe to PATH".
pause
exit /b 1

:fail
echo.
echo Установка прервалась с ошибкой. Скопируйте текст выше и пришлите.
pause
exit /b 1
