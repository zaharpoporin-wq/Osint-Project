"""
report.py
==========

Главная точка входа проекта — запускает ВСЁ одной командой.

Берёт результаты четырёх источников:
  - exif_contract.extract_exif()      — метаданные фото (пишете сами, см. exif_contract.py)
  - sherlock_runner.run_sherlock()    — где засветился username
  - hibp_helper.check_email()         — утечки по email
  - spiderfoot_runner.run_spiderfoot() — расширенная пассивная разведка

...и собирает их в:
  1. сводку прямо в консоли (видно сразу),
  2. Markdown-отчёт  results/report_<дата>.md,
  3. граф связей      results/report_<дата>_graph.html — открывается
     автоматически в браузере в конце работы.

(Экспорт для Maltego .mtgx/.csv — по желанию, флагом --maltego.)

Два способа запуска:

  1) Интерактивно (проще всего) — без параметров, программа сама спросит:
         python report.py
     (или двойной клик по start.bat / запуск start.sh в корне проекта)

  2) С параметрами — удобно для повторных запусков:
         python report.py --photo фото.jpg --username ivan_petrov \\
                          --email ivan@example.com --spiderfoot ivan@example.com

Любой параметр можно пропустить — соответствующий раздел просто не попадёт
в отчёт. Ошибка в одном инструменте не ломает остальные.
"""

from __future__ import annotations

import argparse
import datetime as dt
import os
import sys
from collections import Counter
from pathlib import Path
from typing import Callable, Optional

# Чтобы русский текст нормально печатался в консоли Windows
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")
    except Exception:
        pass

sys.path.insert(0, str(Path(__file__).resolve().parent))

from exif_contract import UnsupportedImage, extract_exif  # noqa: E402
from hibp_helper import check_email  # noqa: E402
from holehe_runner import HoleheNotAvailable, run_holehe  # noqa: E402
from maltego_export import build_graph_edges, export_graph_csv  # noqa: E402
from maltego_graph import export_mtgx  # noqa: E402
from graph_html import export_html  # noqa: E402
from sherlock_runner import SherlockNotAvailable, run_sherlock  # noqa: E402
from spiderfoot_runner import SpiderFootNotAvailable, run_spiderfoot  # noqa: E402

RESULTS_DIR = Path(__file__).resolve().parent.parent / "results"


# --------------------------------------------------------------------------
# 1. Сбор данных
# --------------------------------------------------------------------------

def collect(
    photo: Optional[str] = None,
    username: Optional[str] = None,
    email: Optional[str] = None,
    sf_target: Optional[str] = None,
    hibp_api_key: Optional[str] = None,
    sf_timeout: int = 300,
    progress: Callable[[str], None] = print,
) -> dict:
    """Запускает все выбранные инструменты по очереди. Ошибка одного
    инструмента записывается в results["errors"] и не останавливает
    остальные."""
    steps = [s for s in (photo, username, email, sf_target) if s]
    total = len(steps)
    n = 0
    results: dict = {
        "inputs": {"photo": photo, "username": username, "email": email, "sf_target": sf_target},
        "exif": None,
        "sherlock": None,
        "hibp": None,
        "holehe": None,
        "spiderfoot": None,
        "errors": {},
    }

    if photo:
        n += 1
        progress(f"[{n}/{total}] EXIF: читаю метаданные фото...")
        try:
            results["exif"] = extract_exif(photo)
        except FileNotFoundError:
            results["errors"]["exif"] = f"Файл не найден: {photo}"
        except UnsupportedImage as exc:
            results["errors"]["exif"] = str(exc)

    if username:
        n += 1
        progress(f"[{n}/{total}] Sherlock: ищу «{username}» на 400+ сайтах (обычно 1–3 минуты)...")
        try:
            results["sherlock"] = run_sherlock(username, timeout=30)
        except SherlockNotAvailable as exc:
            results["errors"]["sherlock"] = str(exc)
        except Exception as exc:
            results["errors"]["sherlock"] = f"Sherlock завершился с ошибкой: {exc}"

    if email:
        n += 1
        progress(f"[{n}/{total}] Have I Been Pwned: проверяю {email}...")
        try:
            results["hibp"] = check_email(email, api_key=hibp_api_key)
        except Exception as exc:
            results["errors"]["hibp"] = f"Ошибка HIBP: {exc}"

        progress(f"[{n}/{total}] Holehe: ищу, где зарегистрирована почта {email} (~120 сайтов)...")
        try:
            results["holehe"] = run_holehe(email, timeout=10)
        except HoleheNotAvailable as exc:
            results["errors"]["holehe"] = str(exc)
        except Exception as exc:
            results["errors"]["holehe"] = f"Holehe завершился с ошибкой: {exc}"

    if sf_target:
        n += 1
        limit = f"{sf_timeout // 60} мин" if sf_timeout >= 60 else f"{sf_timeout} с"
        progress(f"[{n}/{total}] SpiderFoot: пассивный скан «{sf_target}» (до {limit})...")
        try:
            results["spiderfoot"] = run_spiderfoot(sf_target, timeout=sf_timeout)
        except SpiderFootNotAvailable as exc:
            results["errors"]["spiderfoot"] = str(exc)
        except Exception as exc:
            results["errors"]["spiderfoot"] = f"SpiderFoot завершился с ошибкой: {exc}"

    return results


# --------------------------------------------------------------------------
# 2. Markdown-отчёт
# --------------------------------------------------------------------------

def _md_exif(res: dict) -> list[str]:
    lines = ["## Метаданные фотографии (EXIF)", ""]
    if "exif" in res["errors"]:
        return lines + [f"_Ошибка: {res['errors']['exif']}_", ""]
    data = res["exif"]
    if not data["has_exif"]:
        return lines + [
            f"Файл **{data['file']}** — EXIF-метаданные не найдены "
            "(скорее всего, удалены мессенджером/соцсетью при отправке).",
            "",
        ]
    lines += [f"Файл: **{data['file']}**", "", "| Параметр | Значение |", "|---|---|"]
    device = f"{data['make'] or ''} {data['model'] or ''}".strip() or "—"
    lines.append(f"| Устройство | {device} |")
    lines.append(f"| Объектив | {data.get('lens') or '—'} |")
    lines.append(f"| Программа/ПО | {data['software'] or '—'} |")
    lines.append(f"| Дата съёмки | {data['datetime_original'] or '—'} |")
    lines.append(f"| Автор / владелец камеры | {data.get('author') or '—'} |")
    if data["gps"]:
        g = data["gps"]
        lines.append(f"| GPS-координаты | {g['lat']}, {g['lon']} ([открыть на карте]({g['maps_url']})) |")
    else:
        lines.append("| GPS-координаты | не найдены в файле |")
    return lines + [""]


def _md_sherlock(res: dict) -> list[str]:
    username = res["inputs"]["username"]
    lines = ["## Поиск по username (Sherlock)", ""]
    if "sherlock" in res["errors"]:
        return lines + [f"_Ошибка: {res['errors']['sherlock']}_", ""]
    found = res["sherlock"]
    if not found:
        return lines + [f"Для username **{username}** подтверждённых профилей не найдено.", ""]
    lines += [f"Username **{username}** найден на {len(found)} сайтах:", "", "| Сайт | Ссылка |", "|---|---|"]
    lines += [f"| {item['site']} | {item['url']} |" for item in found]
    return lines + [""]


def _md_hibp(res: dict) -> list[str]:
    email = res["inputs"]["email"]
    lines = ["## Проверка утечек (Have I Been Pwned)", ""]
    if "hibp" in res["errors"]:
        return lines + [f"_Ошибка: {res['errors']['hibp']}_", ""]
    r = res["hibp"]
    if r["mode"] == "manual":
        return lines + [
            "Автоматическая проверка недоступна без платного API-ключа. "
            f"Проверьте вручную (бесплатно): {r['manual_check_url']}",
            "",
        ]
    if not r["breached"]:
        return lines + [f"Email **{email}** не найден ни в одной известной утечке.", ""]
    lines += [f"Email **{email}** найден в {len(r['breaches'])} утечках:", ""]
    lines += [f"- **{b['name']}** ({b['date']})" for b in r["breaches"]]
    return lines + [""]


def _md_holehe(res: dict) -> list[str]:
    email = res["inputs"]["email"]
    lines = ["## Где зарегистрирована почта (Holehe)", ""]
    if "holehe" in res["errors"]:
        return lines + [f"_Ошибка: {res['errors']['holehe']}_", ""]
    found = res["holehe"]
    if not found:
        return lines + [f"Для **{email}** не нашлось сайтов с подтверждённой регистрацией.", ""]
    lines += [f"Почта **{email}** зарегистрирована на {len(found)} сайтах:", "", "| Сайт | Доп. информация |", "|---|---|"]
    lines += [f"| {item['site']} | {item.get('info', '') or '—'} |" for item in found]
    return lines + [""]


def _md_spiderfoot(res: dict, max_per_type: int = 15) -> list[str]:
    lines = ["## Расширенная пассивная разведка (SpiderFoot)", ""]
    if "spiderfoot" in res["errors"]:
        return lines + [f"_Ошибка: {res['errors']['spiderfoot']}_", ""]
    sf = res["spiderfoot"]
    lines.append(f"Цель: **{sf['target']}**")
    if not sf["finished"]:
        lines.append("")
        lines.append("_Скан остановлен по таймауту — ниже то, что успели найти._")
    lines.append("")
    if not sf["events"]:
        return lines + ["Ничего не найдено.", ""]

    by_type: dict[str, list[str]] = {}
    for ev in sf["events"]:
        values = by_type.setdefault(ev["type"] or "?", [])
        if ev["data"] not in values:
            values.append(ev["data"])

    for ev_type, values in sorted(by_type.items(), key=lambda kv: -len(kv[1])):
        lines.append(f"### {ev_type} ({len(values)})")
        lines.append("")
        for v in values[:max_per_type]:
            lines.append(f"- {str(v).replace(chr(10), ' ')[:300]}")
        if len(values) > max_per_type:
            lines.append(f"- … и ещё {len(values) - max_per_type}")
        lines.append("")
    return lines


def render_markdown(res: dict) -> str:
    parts = [
        "# Отчёт OSINT-аудита цифрового следа",
        "",
        f"Дата формирования: {dt.datetime.now():%Y-%m-%d %H:%M}",
        "",
        "_Отчёт сформирован автоматически инструментом проекта. "
        "Проверьте данные перед использованием в выводах._",
        "",
    ]
    if res["inputs"]["photo"]:
        parts += _md_exif(res)
    if res["inputs"]["username"]:
        parts += _md_sherlock(res)
    if res["inputs"]["email"]:
        parts += _md_hibp(res)
        parts += _md_holehe(res)
    if res["inputs"]["sf_target"]:
        parts += _md_spiderfoot(res)
    return "\n".join(parts)


def build_report(photo=None, username=None, email=None, hibp_api_key=None, sf_target=None) -> str:
    """Совместимость со старым вызовом: собрать данные и вернуть Markdown."""
    res = collect(photo, username, email, sf_target, hibp_api_key, progress=lambda _m: None)
    return render_markdown(res)


# --------------------------------------------------------------------------
# 3. Сводка в консоли
# --------------------------------------------------------------------------

def render_console_summary(res: dict) -> str:
    out = ["", "=" * 60, "  ИТОГ", "=" * 60]

    if res["inputs"]["photo"]:
        out.append("\nФОТО (EXIF)")
        if "exif" in res["errors"]:
            out.append(f"  ✗ {res['errors']['exif']}")
        elif not res["exif"]["has_exif"]:
            out.append("  Метаданных нет (вероятно, стёрты при пересылке).")
        else:
            d = res["exif"]
            device = f"{d['make'] or ''} {d['model'] or ''}".strip()
            out.append(f"  Устройство:  {device or '—'}")
            out.append(f"  Снято:       {d['datetime_original'] or '—'}")
            if d.get("author"):
                out.append(f"  Автор:       {d['author']}")
            if d["gps"]:
                out.append(f"  Место:       {d['gps']['lat']}, {d['gps']['lon']}")
                out.append(f"  Карта:       {d['gps']['maps_url']}")
            else:
                out.append("  Место:       GPS в файле нет")

    if res["inputs"]["username"]:
        out.append("\nSHERLOCK")
        if "sherlock" in res["errors"]:
            out.append(f"  ✗ {res['errors']['sherlock']}")
        else:
            found = res["sherlock"]
            out.append(f"  Найдено профилей: {len(found)}")
            for item in found[:10]:
                out.append(f"    • {item['site']}: {item['url']}")
            if len(found) > 10:
                out.append(f"    … и ещё {len(found) - 10} (см. отчёт)")

    if res["inputs"]["email"]:
        out.append("\nHAVE I BEEN PWNED")
        if "hibp" in res["errors"]:
            out.append(f"  ✗ {res['errors']['hibp']}")
        elif res["hibp"]["mode"] == "manual":
            out.append(f"  Ручная проверка: {res['hibp']['manual_check_url']}")
        elif res["hibp"]["breached"]:
            out.append(f"  Найден в утечках: {len(res['hibp']['breaches'])}")
        else:
            out.append("  В известных утечках не найден.")

        out.append("\nHOLEHE (регистрация почты)")
        if "holehe" in res["errors"]:
            out.append(f"  ✗ {res['errors']['holehe']}")
        else:
            holehe = res["holehe"]
            out.append(f"  Зарегистрирована на сайтах: {len(holehe)}")
            for item in holehe[:10]:
                out.append(f"    • {item['site']}")
            if len(holehe) > 10:
                out.append(f"    … и ещё {len(holehe) - 10} (см. отчёт)")

    if res["inputs"]["sf_target"]:
        out.append("\nSPIDERFOOT")
        if "spiderfoot" in res["errors"]:
            out.append(f"  ✗ {res['errors']['spiderfoot']}")
        else:
            sf = res["spiderfoot"]
            counts = Counter(ev["type"] for ev in sf["events"])
            status = "" if sf["finished"] else " (остановлен по таймауту)"
            out.append(f"  Находок: {len(sf['events'])}{status}")
            for ev_type, cnt in counts.most_common(8):
                out.append(f"    • {ev_type}: {cnt}")

    return "\n".join(out)


# --------------------------------------------------------------------------
# 4. Интерактивный ввод
# --------------------------------------------------------------------------

def open_in_default_app(path) -> bool:
    """Открывает файл программой по умолчанию (для .mtgx это Maltego, если
    установлена). Возвращает True, если удалось запустить открытие."""
    import subprocess
    path = str(path)
    try:
        if sys.platform == "win32":
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def _clean_path(raw: str) -> str:
    """Если перетащить файл в окно терминала, путь вставится в кавычках
    (Windows) или с экранированными пробелами (Mac) — чистим это."""
    raw = raw.strip().strip('"').strip("'")
    if os.name != "nt":
        raw = raw.replace("\\ ", " ")
    return raw


def ask_inputs() -> dict:
    print("=" * 60)
    print("  OSINT-аудит цифрового следа")
    print("=" * 60)
    print("Заполните то, что знаете. Пустой ввод (просто Enter) — пропустить.\n")

    photo = _clean_path(input("1) Фото — путь к файлу (можно перетащить файл в это окно):\n   > "))
    username = input("2) Username / никнейм для Sherlock (например ivan_petrov):\n   > ").strip()
    email = input("3) Email — проверим, где зарегистрирован (Holehe) и в утечках (HIBP):\n   > ").strip()

    sf_target = ""
    default_sf = email or username
    hint = f" [Enter = {default_sf}, «-» = пропустить]" if default_sf else ""
    answer = input(
        "4) SpiderFoot — цель для расширенного скана, идёт до 5 минут\n"
        f"   (email, домен или имя в кавычках){hint}:\n   > "
    ).strip()
    if answer == "-":
        sf_target = ""
    elif answer:
        sf_target = answer
    else:
        sf_target = default_sf

    print()
    return {"photo": photo or None, "username": username or None, "email": email or None, "sf_target": sf_target or None}


# --------------------------------------------------------------------------
# 5. Точка входа
# --------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="OSINT-аудит: EXIF + Sherlock + Holehe + HIBP + SpiderFoot одной командой")
    parser.add_argument("--photo", help="Путь к фотографии для анализа EXIF")
    parser.add_argument("--username", help="Username для поиска через Sherlock")
    parser.add_argument("--email", help="Email для проверки через Have I Been Pwned")
    parser.add_argument("--spiderfoot", dest="sf_target", help='Цель для SpiderFoot: email, домен или "Имя Фамилия"')
    parser.add_argument("--sf-timeout", type=int, default=300, help="Максимум секунд на скан SpiderFoot (по умолчанию 300)")
    parser.add_argument("--hibp-api-key", default=os.environ.get("HIBP_API_KEY"), help="Платный API-ключ HIBP (необязательно)")
    parser.add_argument("--out", default=None, help="Куда сохранить отчёт (по умолчанию results/report_<дата>.md)")
    parser.add_argument("--no-open", action="store_true", help="Не открывать граф автоматически в конце")
    parser.add_argument("--maltego", action="store_true", help="Дополнительно выгрузить файлы для Maltego (.mtgx и .csv)")
    args = parser.parse_args()

    inputs = {"photo": args.photo, "username": args.username, "email": args.email, "sf_target": args.sf_target}
    interactive = not any(inputs.values())
    if interactive:
        inputs = ask_inputs()
        if not any(inputs.values()):
            print("Ничего не введено — нечего проверять.")
            return

    res = collect(**inputs, hibp_api_key=args.hibp_api_key, sf_timeout=args.sf_timeout)

    if args.out:
        out_md = Path(args.out)
    else:
        RESULTS_DIR.mkdir(exist_ok=True)
        out_md = RESULTS_DIR / f"report_{dt.datetime.now():%Y-%m-%d_%H-%M-%S}.md"
    out_md.write_text(render_markdown(res), encoding="utf-8")

    # Центральный узел графа: ник → почта → цель SpiderFoot → общий ярлык
    inp = res["inputs"]
    if inp["username"]:
        subject_value, subject_type = inp["username"], "Alias"
    elif inp["email"]:
        subject_value, subject_type = inp["email"], "EmailAddress"
    elif inp["sf_target"]:
        subject_value, subject_type = inp["sf_target"], "Phrase"
    else:
        subject_value, subject_type = "Объект аудита", "Person"

    edges = build_graph_edges(
        subject_value=subject_value,
        subject_type=subject_type,
        exif_data=res["exif"],
        sherlock_results=res["sherlock"],
        hibp_result=res["hibp"],
        spiderfoot_result=res["spiderfoot"],
        email=res["inputs"]["email"],
        holehe_results=res["holehe"],
    )
    # Наш собственный граф — открывается мгновенно в браузере
    out_html = out_md.with_name(out_md.stem + "_graph.html")
    export_html(edges, out_html, root_value=subject_value, root_type=subject_type)

    print(render_console_summary(res))
    print("\n" + "-" * 60)
    print(f"Отчёт:  {out_md}")
    print(f"Граф:   {out_html}")

    # Необязательный экспорт для Maltego (только с флагом --maltego)
    if args.maltego:
        out_csv = out_md.with_name(out_md.stem + "_maltego.csv")
        export_graph_csv(edges, out_csv)
        out_mtgx = out_md.with_name(out_md.stem + "_maltego.mtgx")
        export_mtgx(edges, out_mtgx)
        print(f"Maltego: {out_mtgx} / {out_csv}")

    # Автооткрытие нашего графа в браузере
    if not args.no_open and edges:
        if open_in_default_app(out_html):
            print("\nОткрываю граф в браузере...")
        else:
            print(f"\nОткройте граф вручную: {out_html}")


if __name__ == "__main__":
    main()
