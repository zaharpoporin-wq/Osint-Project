"""
exif_contract.py
=================

Контракт (интерфейс) между EXIF-утилитой и остальным проектом + рабочая
базовая реализация на Pillow.

Зачем так: чтобы отчёт (report.py) и остальная "обвязка" не зависели от
того, как именно устроена ваша EXIF-утилита внутри, она должна отдавать
результат в одном и том же виде — вот этот вид описан ниже как словарь
(dict) с фиксированными ключами.

Вы (команда) можете:
  а) использовать extract_exif() как есть,
  б) переписать extract_exif() полностью по-своему — главное, чтобы
     на выходе был словарь с теми же ключами, тогда report.py и
     maltego_export.py продолжат работать без изменений.

Формат результата:
{
    "file": "photo.jpg",
    "has_exif": True/False,
    "make": "Apple" | None,              # производитель устройства
    "model": "iPhone 13" | None,         # модель устройства
    "software": "17.4.1" | None,         # версия ПО/прошивки
    "datetime_original": "2026:03:14 12:31:09" | None,
    "lens": "iPhone 13 Pro back camera 5.7mm f/1.5" | None,
    "author": "Ivan Petrov" | None,      # Artist / CameraOwnerName, если камера их записала
    "copyright": "..." | None,
    "gps": {
        "lat": 55.751244,                # десятичные градусы
        "lon": 37.618423,
        "maps_url": "https://www.google.com/maps?q=55.751244,37.618423"
    } | None,
}

Где что лежит внутри файла (это важно понимать для защиты):
  - IFD0 (основной блок): Make, Model, Software, DateTime (дата ИЗМЕНЕНИЯ
    файла), Artist, Copyright.
  - Exif sub-IFD (тег 0x8769): DateTimeOriginal (дата СЪЁМКИ), LensModel,
    CameraOwnerName — реальные камеры и телефоны пишут дату съёмки именно
    сюда, а не в IFD0.
  - GPS sub-IFD (тег 0x8825): координаты в формате градусы/минуты/секунды.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PIL import Image, UnidentifiedImageError
from PIL.ExifTags import GPSTAGS, TAGS

# Фото с iPhone по умолчанию сохраняются в HEIC, а не JPG. Pillow сам HEIC
# не читает — для этого нужен пакет pillow-heif (есть в requirements.txt).
# Если он не установлен, JPG/PNG всё равно будут работать.
try:
    from pillow_heif import register_heif_opener

    register_heif_opener()
    HEIC_SUPPORTED = True
except ImportError:
    HEIC_SUPPORTED = False

EXIF_SUB_IFD = 0x8769
GPS_SUB_IFD = 0x8825


class UnsupportedImage(ValueError):
    """Файл не является изображением, которое мы умеем открыть."""


def _clean(value) -> Optional[str]:
    """EXIF-строки часто заканчиваются нулевыми байтами или пробелами."""
    if value is None:
        return None
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="ignore")
    value = str(value).strip().strip("\x00").strip()
    return value or None


def _dms_to_decimal(dms, ref: str) -> float:
    """Переводит GPS-координату из формата градусы/минуты/секунды (как она
    хранится в EXIF) в десятичные градусы (как нужно для карт)."""
    degrees, minutes, seconds = (float(x) for x in dms)
    decimal = degrees + minutes / 60.0 + seconds / 3600.0
    if ref in ("S", "W"):
        decimal = -decimal
    return decimal


def _extract_gps(gps_info: dict) -> Optional[dict]:
    if not gps_info:
        return None

    gps = {GPSTAGS.get(key, key): value for key, value in gps_info.items()}
    try:
        lat = _dms_to_decimal(gps["GPSLatitude"], _clean(gps.get("GPSLatitudeRef")) or "N")
        lon = _dms_to_decimal(gps["GPSLongitude"], _clean(gps.get("GPSLongitudeRef")) or "E")
    except (KeyError, TypeError, ValueError, ZeroDivisionError):
        return None

    # Координаты 0,0 — это почти всегда "пустышка", а не реальное место
    if lat == 0 and lon == 0:
        return None

    return {
        "lat": round(lat, 6),
        "lon": round(lon, 6),
        "maps_url": f"https://www.google.com/maps?q={lat:.6f},{lon:.6f}",
    }


def extract_exif(photo_path: str | Path) -> dict:
    """Базовая (референсная) реализация. Команда может заменить её своей —
    формат возвращаемого словаря должен остаться таким же (см. докстринг
    модуля выше)."""
    photo_path = Path(photo_path)
    result = {
        "file": photo_path.name,
        "has_exif": False,
        "make": None,
        "model": None,
        "software": None,
        "datetime_original": None,
        "lens": None,
        "author": None,
        "copyright": None,
        "gps": None,
    }

    try:
        img = Image.open(photo_path)
    except UnidentifiedImageError:
        hint = ""
        if photo_path.suffix.lower() in (".heic", ".heif") and not HEIC_SUPPORTED:
            hint = " Это HEIC (формат iPhone) — установите pillow-heif: pip install pillow-heif"
        raise UnsupportedImage(f"Не удалось открыть {photo_path.name} как изображение.{hint}")

    with img:
        raw = img.getexif()
        if not raw:
            return result

        # 1) основной блок IFD0
        tags = {TAGS.get(tag_id, tag_id): value for tag_id, value in raw.items()}

        # 2) Exif sub-IFD — тут у настоящих фото лежит дата съёмки, объектив и т.д.
        try:
            for tag_id, value in raw.get_ifd(EXIF_SUB_IFD).items():
                tags.setdefault(TAGS.get(tag_id, tag_id), value)
        except Exception:
            pass

        # 3) GPS sub-IFD
        try:
            gps_ifd = raw.get_ifd(GPS_SUB_IFD)
        except Exception:
            gps_ifd = None

    result["has_exif"] = True
    result["make"] = _clean(tags.get("Make"))
    result["model"] = _clean(tags.get("Model"))
    result["software"] = _clean(tags.get("Software"))
    result["datetime_original"] = _clean(tags.get("DateTimeOriginal")) or _clean(tags.get("DateTime"))
    result["lens"] = _clean(tags.get("LensModel"))
    result["author"] = _clean(tags.get("Artist")) or _clean(tags.get("CameraOwnerName"))
    result["copyright"] = _clean(tags.get("Copyright"))
    result["gps"] = _extract_gps(gps_ifd)

    return result


if __name__ == "__main__":
    import json
    import sys

    if len(sys.argv) != 2:
        print("Использование: python exif_contract.py путь/к/фото.jpg")
        raise SystemExit(1)

    try:
        data = extract_exif(sys.argv[1])
    except UnsupportedImage as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        raise SystemExit(1)

    print(json.dumps(data, ensure_ascii=False, indent=2))
