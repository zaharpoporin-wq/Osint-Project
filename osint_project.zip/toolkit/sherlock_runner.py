"""
sherlock_runner.py
===================

Обёртка над официальным Sherlock (https://github.com/sherlock-project/sherlock).

Мы НЕ копируем и не переписываем код Sherlock — мы запускаем его как
есть (отдельный официальный проект, MIT license) и забираем результат
в удобном для нашего отчёта виде.

Требование: Sherlock должен быть установлен в окружении, где вы это
запускаете (см. README.md в корне проекта — команда
`pip install ./sherlock`). Внутри песочницы, где собирался этот проект,
живого доступа к PyPI не было, поэтому реальный запуск нужно делать на
своей машине — но код ниже уже готов к работе.

Что делает модуль:
  1. run_sherlock(username, ...) — запускает Sherlock как подпроцесс
     (`python -m sherlock_project <username> --csv --folderoutput <tmp>`),
     дожидается результата.
  2. parse_sherlock_csv(path) — читает CSV, который Sherlock сам умеет
     создавать (--csv), и превращает в список словарей.

Формат одного найденного совпадения (то, что видит report.py):
{
    "username": "ivan_petrov",
    "site": "GitHub",
    "url": "https://github.com/ivan_petrov",
    "http_status": 200,
}
"""

from __future__ import annotations

import csv
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional


class SherlockNotAvailable(RuntimeError):
    """Sherlock не установлен в текущем окружении Python."""


def _sherlock_is_installed() -> bool:
    try:
        import sherlock_project  # noqa: F401

        return True
    except ImportError:
        return False


def run_sherlock(
    username: str,
    timeout: int = 60,
    site_list: Optional[list[str]] = None,
    python_executable: Optional[str] = None,
) -> list[dict]:
    """Запускает официальный Sherlock для одного username и возвращает
    список найденных профилей (claimed=True).

    Бросает SherlockNotAvailable, если пакет sherlock_project не
    установлен — в этом случае установите его согласно README.md
    (`pip install ./sherlock` из папки проекта, на СВОЕЙ машине, не в
    этой песочнице).
    """
    if not _sherlock_is_installed():
        raise SherlockNotAvailable(
            "Пакет sherlock_project не найден. Установите Sherlock в своём "
            "окружении: pip install ./sherlock (см. README.md)."
        )

    python_executable = python_executable or sys.executable

    with tempfile.TemporaryDirectory(prefix="sherlock_out_") as out_dir:
        cmd = [
            python_executable,
            "-m",
            "sherlock_project",
            username,
            "--csv",
            "--folderoutput",
            out_dir,
            "--timeout",
            str(timeout),
        ]
        for site in site_list or []:
            cmd += ["--site", site]

        subprocess.run(cmd, check=True, capture_output=True, text=True)

        csv_path = Path(out_dir) / f"{username}.csv"
        if not csv_path.exists():
            return []
        return parse_sherlock_csv(csv_path)


def parse_sherlock_csv(csv_path: str | Path) -> list[dict]:
    """Парсит CSV-файл, который Sherlock создаёт флагом --csv.

    Колонки в исходном CSV: username,name,url_main,url_user,exists,
    http_status,response_time_s. Нас интересуют только строки, где
    exists == 'Claimed' (аккаунт подтверждённо существует).
    """
    csv_path = Path(csv_path)
    found = []
    with csv_path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if "Claimed" not in row.get("exists", ""):
                continue
            found.append(
                {
                    "username": row.get("username"),
                    "site": row.get("name"),
                    "url": row.get("url_user"),
                    "http_status": row.get("http_status"),
                }
            )
    return found


if __name__ == "__main__":
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Запуск Sherlock для одного username")
    parser.add_argument("username")
    parser.add_argument("--timeout", type=int, default=60)
    args = parser.parse_args()

    try:
        data = run_sherlock(args.username, timeout=args.timeout)
    except SherlockNotAvailable as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        raise SystemExit(1)

    print(json.dumps(data, ensure_ascii=False, indent=2))
