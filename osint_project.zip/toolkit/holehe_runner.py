"""
holehe_runner.py
================

Обёртка над Holehe (https://github.com/megadose/holehe) — инструментом,
который проверяет, на каких сайтах зарегистрирована ПОЧТА.

Идея (и в этом вся суть): Sherlock ищет по НИКУ, но ник не уникален —
«zachura» может быть у многих разных людей. А почта у каждого своя,
поэтому идентификация по почте точнее. Holehe — это «Sherlock для почты»:
он по одному адресу проверяет ~120 сайтов (Instagram, Twitter, Spotify,
Discord и т.д.) через формы регистрации/восстановления пароля и говорит,
где этот адрес уже зарегистрирован.

Holehe ставится отдельно (`pip install ./holehe`, см. README). Внутри этой
песочницы живого доступа к PyPI не было, поэтому реальный запуск — на
вашей машине; код ниже уже готов к работе.

Лицензия Holehe — GPLv3 (это отдельный проект, мы его только запускаем).

Формат одного результата (то, что видит report.py):
    {"site": "twitter.com", "info": "te****@gmail.com"}   # info — подсказка, если есть
"""

from __future__ import annotations

import re
import subprocess
import sys
from typing import Optional

# Строка вида: [+] twitter.com   (возможна доп. информация после домена)
_USED_RE = re.compile(r"^\[\+\]\s+(\S+)\s*(.*)$")


class HoleheNotAvailable(RuntimeError):
    """Holehe не установлен в текущем окружении Python."""


def _holehe_is_installed() -> bool:
    try:
        import holehe  # noqa: F401

        return True
    except ImportError:
        return False


def parse_holehe_output(text: str) -> list[dict]:
    """Разбирает вывод Holehe (с флагом --only-used): берём строки [+] ..."""
    found = []
    for line in text.splitlines():
        m = _USED_RE.match(line.strip())
        if m:
            found.append({"site": m.group(1), "info": m.group(2).strip()})
    return found


def run_holehe(email: str, timeout: int = 10, python_executable: Optional[str] = None) -> list[dict]:
    """Запускает Holehe для одного email и возвращает список сайтов, где
    этот адрес зарегистрирован.

    Бросает HoleheNotAvailable, если пакет holehe не установлен.
    """
    if not _holehe_is_installed():
        raise HoleheNotAvailable(
            "Пакет holehe не найден. Установите его: pip install ./holehe (см. README.md)."
        )

    python_executable = python_executable or sys.executable
    # у holehe нет __main__, поэтому запускаем через его точку входа
    cmd = [
        python_executable, "-c", "from holehe.core import main; main()",
        email, "--only-used", "--no-color", "--no-clear", "-T", str(timeout),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")
    return parse_holehe_output(proc.stdout or "")


if __name__ == "__main__":
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Проверка регистрации почты через Holehe")
    parser.add_argument("email")
    parser.add_argument("--timeout", type=int, default=10)
    args = parser.parse_args()

    try:
        data = run_holehe(args.email, timeout=args.timeout)
    except HoleheNotAvailable as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        raise SystemExit(1)

    print(json.dumps(data, ensure_ascii=False, indent=2))
