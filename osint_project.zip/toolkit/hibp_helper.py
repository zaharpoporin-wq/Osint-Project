"""
hibp_helper.py
===============

Обёртка над Have I Been Pwned (HIBP) — сервисом Троя Ханта для проверки
утечек (https://haveibeenpwned.com/).

ВАЖНО (честно, чтобы в отчёте/защите не было сюрпризов):
  - Ручная проверка ОДНОГО email на сайте haveibeenpwned.com — бесплатна,
    без ключа, просто через браузер.
  - Автоматическая проверка через API (то, что нужно, если хотим
    проверять email программно, как в этом модуле) — теперь ПЛАТНАЯ.
    Нужен API-ключ по подписке (тарифы отличаются лимитом запросов в
    минуту, например «Core» ~10 RPM, «Pro» — намного больше). Бесплатного
    API-ключа у HIBP больше нет.

Из-за этого модуль работает в двух режимах:
  1. Без api_key — НЕ делает сетевой запрос, а просто формирует прямую
     ссылку для ручной проверки на сайте. Это честный и легальный способ
     получить результат без платной подписки — просто не автоматический.
  2. С api_key (если команда/руководитель решит оплатить подписку) —
     обращается к официальному API v3 и возвращает список утечек.

Формат результата (одинаковый в обоих режимах, см. report.py):
{
    "email": "test@example.com",
    "mode": "manual" | "api",
    "manual_check_url": "https://haveibeenpwned.com/account/test%40example.com",
    "breached": True/False/None,   # None = неизвестно, нужна ручная проверка
    "breaches": [ {"name": "...", "date": "..."}, ... ]  # только в режиме api
}
"""

from __future__ import annotations

import time
import urllib.parse
from typing import Optional

HIBP_API_BASE = "https://haveibeenpwned.com/api/v3/breachedaccount/"
HIBP_MANUAL_BASE = "https://haveibeenpwned.com/account/"


def check_email(
    email: str,
    api_key: Optional[str] = None,
    user_agent: str = "OSINT-uchebny-proekt",
) -> dict:
    """Проверяет email на HIBP.

    Если api_key не передан — возвращает ссылку для ручной проверки
    (ничего никуда не отправляет, это не сетевой вызов).

    Если api_key передан — делает запрос к официальному API v3.
    """
    manual_url = HIBP_MANUAL_BASE + urllib.parse.quote(email)

    if not api_key:
        return {
            "email": email,
            "mode": "manual",
            "manual_check_url": manual_url,
            "breached": None,
            "breaches": [],
            "note": (
                "Платного API-ключа нет — зайдите по ссылке manual_check_url "
                "и проверьте email вручную на сайте HIBP (это бесплатно)."
            ),
        }

    import requests  # импортируем здесь, чтобы модуль не требовал requests, когда ключ не используется

    url = HIBP_API_BASE + urllib.parse.quote(email)
    headers = {"hibp-api-key": api_key, "user-agent": user_agent}
    params = {"truncateResponse": "false"}

    resp = requests.get(url, headers=headers, params=params, timeout=15)

    if resp.status_code == 404:
        return {
            "email": email,
            "mode": "api",
            "manual_check_url": manual_url,
            "breached": False,
            "breaches": [],
        }

    if resp.status_code == 429:
        # Превышен лимит запросов в минуту — подождать и сообщить вызывающему коду.
        raise RuntimeError(
            "HIBP API: превышен лимит запросов (429). Подождите и попробуйте снова."
        )

    resp.raise_for_status()

    breaches_raw = resp.json()
    breaches = [
        {"name": b.get("Name"), "date": b.get("BreachDate")} for b in breaches_raw
    ]

    return {
        "email": email,
        "mode": "api",
        "manual_check_url": manual_url,
        "breached": True,
        "breaches": breaches,
    }


def check_emails(emails: list[str], api_key: Optional[str] = None, delay: float = 1.6) -> list[dict]:
    """Проверяет несколько email подряд. delay — пауза между запросами в
    секундах (важно соблюдать лимит RPM платного тарифа, иначе будет 429)."""
    results = []
    for i, email in enumerate(emails):
        if i > 0 and api_key:
            time.sleep(delay)
        results.append(check_email(email, api_key=api_key))
    return results


if __name__ == "__main__":
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Проверка email на Have I Been Pwned")
    parser.add_argument("email")
    parser.add_argument("--api-key", default=None, help="Платный API-ключ HIBP (необязательно)")
    args = parser.parse_args()

    result = check_email(args.email, api_key=args.api_key)
    print(json.dumps(result, ensure_ascii=False, indent=2))
