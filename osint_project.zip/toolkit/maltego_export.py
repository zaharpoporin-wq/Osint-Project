"""
maltego_export.py
===================

Экспорт собранных данных для визуализации связей в Maltego CE
(Community Edition, бесплатная — https://www.maltego.com/).

Зачем: Maltego — стандартный инструмент OSINT для построения ГРАФА связей
("объект → почта → утечка", "объект → ник → профиль"). Весь смысл — в
рёбрах между узлами, а не в простом списке.

Поэтому главный экспорт здесь — "граф" (build_graph_edges / export_graph_csv):
одна строка CSV = одно РЕБРО (родитель → потомок). При импорте Maltego сам
рисует связи. В центре графа — объект аудита (ник, почта или имя), от него
идут рёбра ко всем находкам.

CSV-графа колонки:
    parent_value  parent_type   child_value   child_type   note
    (откуда ребро) (тип узла)    (куда ребро)  (тип узла)   (пояснение)

Как импортировать в Maltego CE:
    1. Graph (панель слева) → Import → Import Graph from Table
       (или File → Import → Import Graph from Table)
    2. Укажите разделитель "," и что первая строка — заголовки.
    3. Connectivity (связи): выберите 2 сущности в строке —
         parent_value  (тип берём из parent_type)
         child_value   (тип берём из child_type)
       и соедините их связью (link). note можно привязать как подпись связи.
    4. Finish — Maltego построит граф автоматически.

Типы (child_type/parent_type) — это подсказка, какой Entity Type выбрать
при маппинге: Person, EmailAddress, Alias, URL, Location, Device, Phrase,
PhoneNumber, Domain, IPv4Address.

Ниже также оставлен старый "плоский" экспорт (build_rows / export_csv) —
список сущностей без связей, на случай если нужен именно он.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Optional

# Типы событий SpiderFoot → типы сущностей Maltego (что не в списке — Phrase)
_SF_TO_MALTEGO = {
    "Email Address": "EmailAddress",
    "Username": "Alias",
    "Human Name": "Person",
    "Phone Number": "PhoneNumber",
    "Internet Name": "Domain",
    "Domain Name": "Domain",
    "IP Address": "IPv4Address",
    "Linked URL - External": "URL",
    "Linked URL - Internal": "URL",
    "Social Media Presence": "URL",
    "Account on External Site": "URL",
    "Physical Location": "Location",
}


# ===========================================================================
# ГЛАВНЫЙ ЭКСПОРТ — ГРАФ СВЯЗЕЙ (рёбра родитель → потомок)
# ===========================================================================

def build_graph_edges(
    subject_value: str,
    subject_type: str = "Person",
    exif_data: Optional[dict] = None,
    sherlock_results: Optional[list[dict]] = None,
    hibp_result: Optional[dict] = None,
    spiderfoot_result: Optional[dict] = None,
    email: Optional[str] = None,
    holehe_results: Optional[list[dict]] = None,
) -> list[dict]:
    """Строит список рёбер графа с центральным узлом subject_value.

    Каждое ребро — словарь:
      {parent_value, parent_type, child_value, child_type, note}
    """
    edges: list[dict] = []
    seen: set = set()

    def edge(pv, pt, cv, ct, note=""):
        cv = " ".join(str(cv).split())[:500]
        if not cv:
            return
        key = (pv, cv)
        if key in seen:
            return
        seen.add(key)
        edges.append({
            "parent_value": pv, "parent_type": pt,
            "child_value": cv, "child_type": ct, "note": note,
        })

    S, ST = subject_value, subject_type

    # ---- EXIF: фото как промежуточный узел, от него — устройство/место/дата ----
    # Отсутствующие данные НЕ пропускаем, а показываем явно («отсутствует»),
    # чтобы было видно: проверка проведена, но данных нет.
    if exif_data:
        photo = exif_data.get("file") or "фотография"
        edge(S, ST, photo, "Document", "фотография объекта")
        if exif_data.get("author"):
            edge(S, ST, exif_data["author"], "Person", "автор/владелец камеры из EXIF")

        if not exif_data.get("has_exif"):
            edge(photo, "Document", "Метаданные отсутствуют", "Missing",
                 "EXIF не найден (часто стираются при пересылке через мессенджер)")
        else:
            dev = f"{exif_data.get('make') or ''} {exif_data.get('model') or ''}".strip()
            if dev:
                edge(photo, "Document", dev, "Device", exif_data.get("software") or "устройство съёмки")
            else:
                edge(photo, "Document", "Устройство: не определено", "Missing", "в EXIF нет модели")

            if exif_data.get("datetime_original"):
                edge(photo, "Document", exif_data["datetime_original"], "Phrase", "дата/время съёмки")
            else:
                edge(photo, "Document", "Дата съёмки: отсутствует", "Missing", "в EXIF нет даты")

            if exif_data.get("gps"):
                gps = exif_data["gps"]
                edge(photo, "Document", f"{gps['lat']},{gps['lon']}", "Location", gps["maps_url"])
            else:
                edge(photo, "Document", "GPS: отсутствует", "Missing", "геометки в фото нет")

    # ---- Sherlock: объект → профиль (URL) ----
    for item in sherlock_results or []:
        edge(S, ST, item["url"], "URL", f"аккаунт: {item.get('site', '')}")

    # ---- HIBP: объект → почта, почта → утечки ----
    if hibp_result:
        email = hibp_result.get("email")
        if email:
            if hibp_result.get("mode") == "manual":
                edge(S, ST, email, "EmailAddress", "проверить вручную на HIBP")
            else:
                edge(S, ST, email, "EmailAddress", "проверено через HIBP")
                for b in hibp_result.get("breaches", []):
                    edge(email, "EmailAddress", f"Утечка: {b['name']}", "Phrase", b.get("date", ""))

    # ---- Holehe: объект → почта, почта → сайты, где она зарегистрирована ----
    if holehe_results and email:
        edge(S, ST, email, "EmailAddress", "почта объекта")
        for item in holehe_results:
            site = item.get("site")
            if site:
                edge(email, "EmailAddress", site, "Domain", "зарегистрирована по почте")

    # ---- SpiderFoot: объект → находка ----
    for ev in (spiderfoot_result or {}).get("events", []):
        ct = _SF_TO_MALTEGO.get(ev.get("type"), "Phrase")
        edge(S, ST, ev.get("data"), ct, f"{ev.get('type')} ({ev.get('module')})")

    return edges


def export_graph_csv(edges: list[dict], out_path: str | Path) -> Path:
    out_path = Path(out_path)
    fields = ["parent_value", "parent_type", "child_value", "child_type", "note"]
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(edges)
    return out_path


# ===========================================================================
# СТАРЫЙ ЭКСПОРТ — ПЛОСКИЙ СПИСОК (без связей). Оставлен на всякий случай.
# ===========================================================================

def build_rows(
    exif_data: Optional[dict] = None,
    sherlock_results: Optional[list[dict]] = None,
    hibp_result: Optional[dict] = None,
    spiderfoot_result: Optional[dict] = None,
) -> list[dict]:
    rows: list[dict] = []

    if exif_data and exif_data.get("has_exif"):
        if exif_data.get("author"):
            rows.append({"entity_type": "Person", "value": exif_data["author"],
                         "source": "exif", "note": "автор/владелец камеры из EXIF"})
        if exif_data.get("make") or exif_data.get("model"):
            rows.append({"entity_type": "Device",
                         "value": f"{exif_data.get('make') or ''} {exif_data.get('model') or ''}".strip(),
                         "source": "exif", "note": exif_data.get("software") or ""})
        if exif_data.get("gps"):
            gps = exif_data["gps"]
            rows.append({"entity_type": "Location", "value": f"{gps['lat']},{gps['lon']}",
                         "source": "exif", "note": gps["maps_url"]})
        if exif_data.get("datetime_original"):
            rows.append({"entity_type": "Phrase", "value": exif_data["datetime_original"],
                         "source": "exif", "note": "дата/время съёмки"})

    for item in sherlock_results or []:
        rows.append({"entity_type": "URL", "value": item["url"],
                     "source": "sherlock", "note": item["site"]})

    if hibp_result:
        if hibp_result.get("mode") == "manual":
            rows.append({"entity_type": "EmailAddress", "value": hibp_result["email"],
                         "source": "hibp",
                         "note": f"требуется ручная проверка: {hibp_result['manual_check_url']}"})
        elif hibp_result.get("breached"):
            for b in hibp_result.get("breaches", []):
                rows.append({"entity_type": "Phrase", "value": f"Утечка: {b['name']}",
                             "source": "hibp", "note": b.get("date", "")})

    seen = set()
    for ev in (spiderfoot_result or {}).get("events", []):
        key = (ev.get("type"), ev.get("data"))
        if key in seen:
            continue
        seen.add(key)
        rows.append({"entity_type": _SF_TO_MALTEGO.get(ev.get("type"), "Phrase"),
                     "value": " ".join(str(ev.get("data")).split())[:500],
                     "source": "spiderfoot", "note": f"{ev.get('type')} ({ev.get('module')})"})

    return rows


def export_csv(rows: list[dict], out_path: str | Path) -> Path:
    out_path = Path(out_path)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["entity_type", "value", "source", "note"])
        writer.writeheader()
        writer.writerows(rows)
    return out_path


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Собрать демо-CSV графа для Maltego CE")
    parser.add_argument("--out", default="maltego_graph.csv")
    parser.add_argument("--subject", default="ivan_petrov", help="Центральный узел (объект аудита)")
    args = parser.parse_args()

    edges = build_graph_edges(
        subject_value=args.subject,
        subject_type="Alias",
        exif_data={
            "has_exif": True, "file": "photo.jpg", "make": "Apple", "model": "iPhone 13 Pro",
            "software": "17.4.1", "author": "Ivan Petrov", "datetime_original": "2026:03:14 12:31:09",
            "gps": {"lat": 55.751244, "lon": 37.618423,
                    "maps_url": "https://www.google.com/maps?q=55.751244,37.618423"},
        },
        sherlock_results=[
            {"username": args.subject, "site": "GitHub", "url": f"https://github.com/{args.subject}"},
            {"username": args.subject, "site": "Reddit", "url": f"https://www.reddit.com/user/{args.subject}"},
        ],
        hibp_result={"email": "ivan@example.com", "mode": "api", "breached": True,
                     "breaches": [{"name": "LinkedIn", "date": "2012-05-05"},
                                  {"name": "Adobe", "date": "2013-10-04"}]},
    )
    path = export_graph_csv(edges, args.out)
    print(f"Демо-граф сохранён: {path}  (рёбер: {len(edges)})")
