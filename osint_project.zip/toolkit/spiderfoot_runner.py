"""
spiderfoot_runner.py
=====================

Обёртка над официальным SpiderFoot (https://github.com/smicallef/spiderfoot).

У SpiderFoot два режима работы:
  1. Веб-интерфейс:  python sf.py -l 127.0.0.1:5001   (красиво, руками)
  2. Консольный скан: python sf.py -s ЦЕЛЬ -u passive -o json -q
                      (без окон, результат печатается в stdout)

Этот модуль использует режим 2, чтобы SpiderFoot можно было запускать
автоматически из report.py вместе с остальными инструментами.

Что можно дать на вход (SpiderFoot сам определяет тип по виду строки —
см. SpiderFootHelpers.targetTypeFromString в spiderfoot/helpers.py):
    ivan@example.com      → email
    example.com           → домен
    8.8.8.8               → IP-адрес
    +79991234567          → телефон
    "Ivan Petrov"         → имя человека (ОБЯЗАТЕЛЬНО в двойных кавычках)
    "ivan_petrov"         → username (ОБЯЗАТЕЛЬНО в двойных кавычках)

Режим -u passive: только пассивные модули — они не "трогают" цель
напрямую (не сканируют порты и т.п.), а спрашивают открытые источники.
Для учебного проекта это правильный и безопасный режим.

Скан может идти долго (минуты), поэтому есть timeout: по его истечении
скан останавливается, и мы возвращаем то, что успели найти.

Формат результата:
{
    "target": "ivan@example.com",
    "finished": True/False,          # False = остановлен по таймауту
    "events": [ {"module": "sfp_...", "type": "Email Address",
                 "data": "...", "source": "..."}, ... ]
}
"""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
from pathlib import Path
from typing import Optional

# По умолчанию — папка spiderfoot/ рядом с toolkit/. Если SpiderFoot лежит
# в другом месте, укажите путь в переменной окружения SPIDERFOOT_DIR.
SPIDERFOOT_DIR = Path(os.environ.get("SPIDERFOOT_DIR") or Path(__file__).resolve().parent.parent / "spiderfoot")

# Служебные события, которые не несут информации для отчёта
_NOISE_TYPES = {"ROOT", "Scan target"}


class SpiderFootNotAvailable(RuntimeError):
    """SpiderFoot не найден или его зависимости не установлены."""


def normalize_target(target: str) -> str:
    """Если цель — username или имя без кавычек, SpiderFoot её не поймёт.
    Email/домен/IP оставляем как есть, остальное оборачиваем в кавычки."""
    target = target.strip()
    if target.startswith('"') and target.endswith('"'):
        return target
    if "@" in target or "." in target or target.replace("+", "").isdigit():
        return target
    return f'"{target}"'


def parse_spiderfoot_json(output: str) -> list[dict]:
    """SpiderFoot в режиме -o json печатает события по одному на строку:
        [{...},
        {...},
        {...}]
    Парсим построчно — так работает и с оборванным (по таймауту) выводом."""
    events = []
    for line in output.splitlines():
        line = line.strip().lstrip("[").rstrip("]").rstrip(",").strip()
        if not line.startswith("{"):
            continue
        try:
            ev = json.loads(line)
        except json.JSONDecodeError:
            continue
        if ev.get("type") in _NOISE_TYPES:
            continue
        events.append(
            {
                "module": ev.get("module"),
                "type": ev.get("type"),
                "data": ev.get("data"),
                "source": ev.get("source"),
            }
        )
    return events


def _kill_tree(proc: subprocess.Popen) -> None:
    """SpiderFoot запускает скан в дочернем процессе — убиваем всё дерево,
    иначе скан продолжит работать в фоне."""
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(proc.pid)], capture_output=True)
        else:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
    except Exception:
        proc.kill()


def run_spiderfoot(
    target: str,
    timeout: int = 300,
    use_case: str = "passive",
    modules: Optional[list[str]] = None,
    python_executable: Optional[str] = None,
) -> dict:
    sf_script = SPIDERFOOT_DIR / "sf.py"
    if not sf_script.exists():
        raise SpiderFootNotAvailable(f"Не найден {sf_script} — папка spiderfoot/ должна лежать рядом с toolkit/.")

    target = normalize_target(target)
    cmd = [python_executable or sys.executable, str(sf_script), "-s", target, "-o", "json", "-q"]
    if modules:
        cmd += ["-m", ",".join(modules)]
    else:
        cmd += ["-u", use_case]

    popen_kwargs = {}
    if os.name != "nt":
        popen_kwargs["start_new_session"] = True  # чтобы можно было убить всю группу процессов

    proc = subprocess.Popen(
        cmd,
        cwd=SPIDERFOOT_DIR,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        **popen_kwargs,
    )

    finished = True
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        finished = False
        _kill_tree(proc)
        stdout, stderr = proc.communicate()

    if "ModuleNotFoundError" in (stderr or ""):
        missing = stderr.strip().splitlines()[-1]
        raise SpiderFootNotAvailable(
            f"Не установлены зависимости SpiderFoot ({missing}). "
            "Выполните: pip install -r spiderfoot/requirements.txt"
        )

    return {"target": target, "finished": finished, "events": parse_spiderfoot_json(stdout or "")}


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Консольный скан SpiderFoot")
    parser.add_argument("target", help='email, домен, IP или "Имя Фамилия" в кавычках')
    parser.add_argument("--timeout", type=int, default=300, help="Максимум секунд на скан (по умолчанию 300)")
    args = parser.parse_args()

    try:
        res = run_spiderfoot(args.target, timeout=args.timeout)
    except SpiderFootNotAvailable as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        raise SystemExit(1)

    print(json.dumps(res, ensure_ascii=False, indent=2))
