"""
maltego_graph.py
=================

Сборка НАТИВНОГО файла графа Maltego (.mtgx) прямо из наших находок.

Зачем: CSV нужно импортировать через мастер (выбирать колонки и т.д.).
А файл .mtgx — это уже готовый граф: его достаточно ОТКРЫТЬ, и Maltego
сразу покажет узлы и связи, без ручного импорта. Именно это позволяет
программе в конце автоматически открыть готовый граф.

Формат .mtgx — это ZIP-архив, внутри которого:
    Graphs/Graph1.graphml   — описание графа (узлы + связи) в XML (GraphML)
    version.properties      — служебные данные версии

ВАЖНО (честно): точный формат Maltego нельзя было проверить на настоящей
программе при сборке. Если Maltego не откроет файл — используйте CSV-импорт
(см. README), а текст ошибки поможет поправить формат здесь.

На вход идут те же рёбра, что собирает maltego_export.build_graph_edges():
    {parent_value, parent_type, child_value, child_type, note}
"""

from __future__ import annotations

import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

# Наш тип узла -> (тип сущности Maltego, имя главного свойства)
_TYPE_MAP = {
    "Alias":        ("maltego.Alias", "properties.alias"),
    "EmailAddress": ("maltego.EmailAddress", "email"),
    "URL":          ("maltego.URL", "short-title"),
    "Location":     ("maltego.Location", "location.name"),
    "Person":       ("maltego.Person", "person.fullname"),
    "PhoneNumber":  ("maltego.PhoneNumber", "phonenumber"),
    "Domain":       ("maltego.Domain", "fqdn"),
    "IPv4Address":  ("maltego.IPv4Address", "ipv4-address"),
    "Device":       ("maltego.Phrase", "properties.phrase"),   # у Device нет надёжного свойства — через Phrase
    "Document":     ("maltego.Phrase", "properties.phrase"),
    "Phrase":       ("maltego.Phrase", "properties.phrase"),
    "Missing":      ("maltego.Phrase", "properties.phrase"),   # «отсутствует» — тоже текстовый узел
}


def _entity_xml(node_id: str, our_type: str, value: str) -> str:
    mtg_type, prop = _TYPE_MAP.get(our_type, ("maltego.Phrase", "properties.phrase"))
    v = escape(str(value))
    return (
        f'    <node id="{node_id}">\n'
        f'      <data key="MaltegoEntity">\n'
        f'        <mtg:MaltegoEntity type="{mtg_type}">\n'
        f'          <mtg:Properties>\n'
        f'            <mtg:Property name="{prop}" displayName="{prop}" nullable="true" '
        f'hidden="false" readonly="false" type="string">\n'
        f'              <mtg:Value>{v}</mtg:Value>\n'
        f'            </mtg:Property>\n'
        f'          </mtg:Properties>\n'
        f'        </mtg:MaltegoEntity>\n'
        f'      </data>\n'
        f'    </node>\n'
    )


def _edge_xml(edge_id: str, src_id: str, dst_id: str, note: str = "") -> str:
    label = escape(str(note or ""))
    return (
        f'    <edge id="{edge_id}" source="{src_id}" target="{dst_id}">\n'
        f'      <data key="MaltegoLink">\n'
        f'        <mtg:MaltegoLink type="maltego.link.manual">\n'
        f'          <mtg:Properties>\n'
        f'            <mtg:Property name="maltego.link.manual.type" displayName="Link type" '
        f'nullable="true" hidden="false" readonly="false" type="string">\n'
        f'              <mtg:Value>{label}</mtg:Value>\n'
        f'            </mtg:Property>\n'
        f'          </mtg:Properties>\n'
        f'        </mtg:MaltegoLink>\n'
        f'      </data>\n'
        f'    </edge>\n'
    )


def _build_graphml(edges: list[dict]) -> str:
    # собираем уникальные узлы: value -> (id, type)
    nodes: dict[str, tuple[str, str]] = {}

    def ensure(value: str, our_type: str) -> str:
        value = str(value)
        if value not in nodes:
            nodes[value] = (f"n{len(nodes)}", our_type)
        return nodes[value][0]

    edge_parts = []
    for i, e in enumerate(edges):
        sid = ensure(e["parent_value"], e.get("parent_type", "Phrase"))
        did = ensure(e["child_value"], e.get("child_type", "Phrase"))
        edge_parts.append(_edge_xml(f"e{i}", sid, did, e.get("note", "")))

    node_parts = [_entity_xml(nid, ntype, value) for value, (nid, ntype) in nodes.items()]

    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<graphml xmlns="http://graphml.graphdrawing.org/xmlns" '
        'xmlns:mtg="http://maltego.paterva.com/xml/mtgx" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">\n'
        '  <key id="MaltegoEntity" for="node" attr.name="MaltegoEntity"/>\n'
        '  <key id="MaltegoLink" for="edge" attr.name="MaltegoLink"/>\n'
        '  <graph edgedefault="directed">\n'
        + "".join(node_parts)
        + "".join(edge_parts)
        + '  </graph>\n'
        '</graphml>\n'
    )


_VERSION_PROPERTIES = (
    "#Maltego graph\n"
    "maltego.graph.version=1.2\n"
    "maltego.client.name=Maltego CE\n"
    "maltego.client.version=4.6.0\n"
)


def export_mtgx(edges: list[dict], out_path: str | Path) -> Path:
    """Собирает готовый к открытию файл графа Maltego (.mtgx)."""
    out_path = Path(out_path)
    if out_path.suffix.lower() != ".mtgx":
        out_path = out_path.with_suffix(".mtgx")
    graphml = _build_graphml(edges)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("Graphs/Graph1.graphml", graphml)
        z.writestr("version.properties", _VERSION_PROPERTIES)
    return out_path


if __name__ == "__main__":
    import argparse
    from maltego_export import build_graph_edges

    parser = argparse.ArgumentParser(description="Собрать демо-файл графа Maltego (.mtgx)")
    parser.add_argument("--out", default="maltego_graph.mtgx")
    parser.add_argument("--subject", default="ivan_petrov")
    args = parser.parse_args()

    edges = build_graph_edges(
        subject_value=args.subject, subject_type="Alias",
        exif_data={"has_exif": True, "file": "photo.jpg", "make": "Apple", "model": "iPhone 13 Pro",
                   "software": "17.4.1", "author": "Ivan Petrov", "datetime_original": "2026:03:14 12:31:09",
                   "gps": {"lat": 55.751244, "lon": 37.618423,
                           "maps_url": "https://www.google.com/maps?q=55.751244,37.618423"}},
        sherlock_results=[{"username": args.subject, "site": "GitHub", "url": f"https://github.com/{args.subject}"}],
        hibp_result={"email": "ivan@example.com", "mode": "api", "breached": True,
                     "breaches": [{"name": "LinkedIn", "date": "2012-05-05"}]},
    )
    path = export_mtgx(edges, args.out)
    print(f"Файл графа сохранён: {path}  (рёбер: {len(edges)})")
