"""
graph_html.py
=============

Строит ИНТЕРАКТИВНЫЙ граф связей как самостоятельную HTML-страницу
(чистый JavaScript, без внешних библиотек — работает офлайн, ничего
ставить не нужно).

Что умеет готовая страница:
  - большие группы (например, сотни найденных аккаунтов) свёрнуты в один
    узел со счётчиком; клик по нему разворачивает/сворачивает;
  - зум колесом мыши, перетаскивание полотна;
  - клик по узлу открывает панель с полным значением (URL — ещё и ссылкой);
  - кнопки «Развернуть всё / Свернуть всё / Вписать» и поиск по узлам.

На вход — те же рёбра, что собирает maltego_export.build_graph_edges():
    {parent_value, parent_type, child_value, child_type, note}
плюс значение центрального узла (root).
"""

from __future__ import annotations

import html
import json
from pathlib import Path


def _short(text: str, n: int = 30) -> str:
    text = str(text)
    return text if len(text) <= n else text[: n - 1] + "…"


def build_html(edges: list[dict], root_value: str, root_type: str = "Alias") -> str:
    idx: dict[str, int] = {}
    nodes: list[dict] = []

    def nid(value: str, typ: str) -> int:
        value = str(value)
        if value in idx:
            return idx[value]
        i = len(nodes)
        idx[value] = i
        nodes.append({"id": i, "label": _short(value, 30), "full": value, "type": typ, "rel": ""})
        return i

    root_id = nid(root_value, root_type)
    nodes[root_id]["type"] = root_type

    es: list[dict] = []
    for e in edges:
        p = nid(e["parent_value"], e.get("parent_type", "Phrase"))
        c = nid(e["child_value"], e.get("child_type", "Phrase"))
        if not nodes[c]["rel"]:
            nodes[c]["rel"] = str(e.get("note", ""))
        es.append({"from": p, "to": c})

    data = json.dumps({"root": root_id, "nodes": nodes, "edges": es}, ensure_ascii=False)

    return (
        _TEMPLATE
        .replace("__DATA__", data)
        .replace("__ROOTLABEL__", html.escape(str(root_value)))
    )


def export_html(edges: list[dict], out_path, root_value: str, root_type: str = "Alias") -> Path:
    out_path = Path(out_path)
    if out_path.suffix.lower() not in (".html", ".htm"):
        out_path = out_path.with_suffix(".html")
    out_path.write_text(build_html(edges, root_value, root_type), encoding="utf-8")
    return out_path


_TEMPLATE = r"""<!doctype html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Граф цифрового следа</title>
<style>
  :root { --navy:#0B2545; --ink:#13293D; --muted:#5C7A99; --line:#C7D3E0; }
  * { box-sizing: border-box; }
  html,body { margin:0; height:100%; font-family:Calibri,"Segoe UI",system-ui,sans-serif; color:var(--ink); }
  #top { background:var(--navy); color:#fff; padding:12px 18px; display:flex; align-items:center; gap:14px; flex-wrap:wrap; }
  #top h1 { font-size:18px; margin:0; font-weight:700; }
  #top .sub { color:#D9ECF5; font-size:13px; }
  #bar { display:flex; gap:8px; align-items:center; flex-wrap:wrap; padding:8px 18px; background:#fff; border-bottom:1px solid #E1E8F0; }
  #bar button { font:inherit; font-size:13px; padding:6px 12px; border:1px solid #CFE0EC; background:#F3F8FC; color:var(--ink); border-radius:8px; cursor:pointer; }
  #bar button:hover { background:#E6F1F8; }
  #bar input { font:inherit; font-size:13px; padding:6px 10px; border:1px solid #CFE0EC; border-radius:8px; min-width:180px; }
  #legend { font-size:12px; color:var(--muted); margin-left:auto; display:flex; gap:12px; flex-wrap:wrap; }
  #legend span { display:inline-flex; align-items:center; gap:5px; }
  #legend i { width:12px; height:12px; border-radius:3px; display:inline-block; }
  #stage { position:relative; width:100%; height:calc(100% - 104px); overflow:hidden; background:#F4F7FA; cursor:grab; }
  #stage.drag { cursor:grabbing; }
  svg { width:100%; height:100%; display:block; }
  .edge { stroke:var(--line); stroke-width:1.5; }
  .edgelabel { fill:#8CA3BA; font-size:11px; pointer-events:none; }
  .node { cursor:pointer; }
  .node rect { stroke:#fff; stroke-width:2; }
  .node text { fill:#fff; font-size:13px; font-weight:600; pointer-events:none; dominant-baseline:middle; text-anchor:middle; }
  .node .typ { fill:var(--muted); font-size:10px; font-weight:400; }
  .node.cat rect { stroke-dasharray:4 3; }
  .node.hit rect { stroke:#F4B000; stroke-width:4; }
  #panel { position:absolute; top:12px; right:12px; width:300px; max-width:72%; background:#fff; border:1px solid #D7E2EC;
           border-radius:12px; box-shadow:0 6px 24px rgba(11,37,69,.14); padding:14px 16px; font-size:14px; display:none; }
  #panel h3 { margin:0 0 6px; font-size:15px; }
  #panel .k { color:var(--muted); font-size:12px; margin-top:8px; }
  #panel .v { word-break:break-all; }
  #panel a { color:#1C6B8C; }
  #panel .close { position:absolute; top:8px; right:12px; cursor:pointer; color:var(--muted); font-size:18px; }
  #hint { position:absolute; left:12px; bottom:10px; font-size:12px; color:var(--muted); background:rgba(255,255,255,.8); padding:4px 8px; border-radius:6px; }
</style></head>
<body>
  <div id="top">
    <h1>Граф цифрового следа</h1>
    <span class="sub">Объект: <b>__ROOTLABEL__</b></span>
  </div>
  <div id="bar">
    <button id="fit">Вписать</button>
    <div id="legend"></div>
  </div>
  <div id="stage">
    <svg id="svg"><g id="vp"></g></svg>
    <div id="panel"><span class="close" id="pclose">×</span><div id="pbody"></div></div>
    <div id="hint">Колесо — зум · перетаскивание — сдвиг · клик по группе (· N ↗) — список · клик по узлу — детали</div>
  </div>
<script>
const DATA = __DATA__;

const COLORS = {
  Alias:"#0B2545", Person:"#134E6F", EmailAddress:"#1C6B8C", URL:"#2E8B57",
  Domain:"#2E8B57", Location:"#2E6F5E", Device:"#6C4A8F", Phrase:"#5C7A99",
  Document:"#9C5F0E", PhoneNumber:"#1C6B8C", IPv4Address:"#2E8B57", Missing:"#9AA3AD"
};
const DEF = "#5C7A99";
const CAT_LABEL = {
  URL:"Аккаунты (профили)", Domain:"Сайты регистрации", Phrase:"Заметки / утечки",
  EmailAddress:"Почты", Location:"Места", Device:"Устройства", Person:"Люди",
  Document:"Файлы", PhoneNumber:"Телефоны", IPv4Address:"IP-адреса"
};
const color = t => COLORS[t] || DEF;

const N = DATA.nodes;                       // массив узлов по id
const ROOT = DATA.root;
const GROUP_THRESHOLD = 7;                   // больше скольких одинаковых детей сворачивать
const RING = 240;

// --- строим дерево родитель -> дети (первый родитель выигрывает) ---
const childrenOf = {};                       // id -> [childId]
const hasParent = new Set();
for (const e of DATA.edges) {
  if (e.from === e.to) continue;
  if (hasParent.has(e.to)) continue;         // дерево: один родитель
  hasParent.add(e.to);
  (childrenOf[e.from] = childrenOf[e.from] || []).push(e.to);
}

// --- виртуальные категории для крупных групп одинакового типа ---
const effKids = {};    // id -> [{kind:'node',id} | {kind:'cat',key}]
const catMembers = {}; // key -> [childId]
const catInfo = {};    // key -> {type, parent}
for (const pid in childrenOf) {
  const byType = {};
  for (const c of childrenOf[pid]) (byType[N[c].type] = byType[N[c].type] || []).push(c);
  const entries = [];
  for (const t in byType) {
    const arr = byType[t];
    if (arr.length > GROUP_THRESHOLD) {
      const key = "c" + pid + "_" + t;
      catMembers[key] = arr;
      catInfo[key] = { type: t, parent: +pid };
      entries.push({ kind:"cat", key });
    } else {
      for (const c of arr) entries.push({ kind:"node", id:c });
    }
  }
  effKids[pid] = entries;
}

// ключи: "n<id>" для реальных узлов, cat-ключ для категорий
const kNode = id => "n" + id;
function dchildren(key) {
  if (key[0] === "n") {
    const id = +key.slice(1);
    return (effKids[id] || []).map(e => e.kind === "node" ? kNode(e.id) : e.key);
  }
  return [];   // категория — всегда лист в графе (клик открывает список в новой вкладке)
}
function meta(key) {
  if (key[0] === "n") {
    const nd = N[+key.slice(1)];
    return { isCat:false, id:+key.slice(1), label:nd.label, full:nd.full, type:nd.type, rel:nd.rel, root:(+key.slice(1)===ROOT) };
  }
  const ci = catInfo[key], n = catMembers[key].length;
  return { isCat:true, key, type:ci.type, count:n,
           label:(CAT_LABEL[ci.type]||ci.type) + " · " + n + "  ↗" };
}

// --- радиальная раскладка видимого дерева ---
let pos = {};
function layout() {
  pos = {};
  const lc = {};
  const rootKey = kNode(ROOT);
  (function leaves(k){ const ch=dchildren(k); if(!ch.length){lc[k]=1;return 1;} let s=0; for(const c of ch)s+=leaves(c); lc[k]=s; return s; })(rootKey);
  (function place(k,depth,a0,a1,parent){
    const ang=(a0+a1)/2, r=depth*RING;
    pos[k]={ x:r*Math.cos(ang), y:r*Math.sin(ang), depth, parent };
    const ch=dchildren(k); if(!ch.length) return;
    const tot=ch.reduce((s,c)=>s+lc[c],0)||1; let cur=a0;
    for(const c of ch){ const f=lc[c]/tot; place(c,depth+1,cur,cur+(a1-a0)*f,k); cur+=(a1-a0)*f; }
  })(rootKey,0,0,2*Math.PI,null);
}

// --- отрисовка ---
const SVG = "http://www.w3.org/2000/svg";
const vp = document.getElementById("vp");
let hitKeys = new Set();
function esc(s){ return String(s).replace(/[&<>]/g, c=>({ "&":"&amp;","<":"&lt;",">":"&gt;" }[c])); }

function render() {
  layout();
  const keys = Object.keys(pos);
  const showLabels = keys.length <= 60;
  let edgeHTML = "", labelHTML = "", nodeHTML = "";
  for (const k of keys) {
    const p = pos[k];
    if (p.parent) {
      const q = pos[p.parent];
      edgeHTML += `<line class="edge" x1="${q.x.toFixed(0)}" y1="${q.y.toFixed(0)}" x2="${p.x.toFixed(0)}" y2="${p.y.toFixed(0)}"/>`;
      if (showLabels) {
        const m = meta(k);
        if (m.rel) labelHTML += `<text class="edgelabel" x="${((p.x+q.x)/2).toFixed(0)}" y="${((p.y+q.y)/2-3).toFixed(0)}" text-anchor="middle">${esc(m.rel.slice(0,28))}</text>`;
      }
    }
  }
  for (const k of keys) {
    const p = pos[k], m = meta(k);
    const isRoot = m.root, isCat = m.isCat;
    const w = isRoot?210:(isCat?210:184), h = isRoot?52:44;
    const fill = isCat ? color(m.type) : color(m.type);
    const cls = "node" + (isCat?" cat":"") + (hitKeys.has(k)?" hit":"");
    const label = m.label;
    const typ = isCat ? "список — клик" : (isRoot||m.type==="Missing"?"":m.type);
    nodeHTML += `<g class="${cls}" data-k="${k}" transform="translate(${p.x.toFixed(0)},${p.y.toFixed(0)})">`
      + `<rect x="${-w/2}" y="${-h/2}" width="${w}" height="${h}" rx="10" fill="${fill}" opacity="${isCat?0.92:1}"/>`
      + `<text y="${typ?-3:0}" style="font-size:${isRoot?14:13}px;font-weight:${isRoot?700:600}">${esc(label)}</text>`
      + (typ?`<text class="typ" y="13">${esc(typ)}</text>`:"")
      + `</g>`;
  }
  vp.innerHTML = edgeHTML + labelHTML + nodeHTML;
  for (const g of vp.querySelectorAll(".node")) g.addEventListener("click", onNodeClick);
}

// --- вид (пан/зум) ---
let view = { tx: 0, ty: 0, s: 1 };
function applyView(){ vp.setAttribute("transform", `translate(${view.tx},${view.ty}) scale(${view.s})`); }
function fit() {
  const keys = Object.keys(pos); if (!keys.length) return;
  let minX=1e9,minY=1e9,maxX=-1e9,maxY=-1e9;
  for (const k of keys){ const p=pos[k]; minX=Math.min(minX,p.x-130);minY=Math.min(minY,p.y-40);maxX=Math.max(maxX,p.x+130);maxY=Math.max(maxY,p.y+40); }
  const st=document.getElementById("stage"), W=st.clientWidth, H=st.clientHeight;
  const s=Math.min(W/(maxX-minX||1), H/(maxY-minY||1), 1.4)*0.92;
  view.s=s; view.tx=W/2 - (minX+maxX)/2*s; view.ty=H/2 - (minY+maxY)/2*s; applyView();
}

// --- взаимодействие ---
function onNodeClick(ev){
  ev.stopPropagation();
  const k = ev.currentTarget.getAttribute("data-k"), m = meta(k);
  if (m.isCat){ openList(k); return; }
  showPanel(m);
}

// --- список членов группы в отдельной красиво оформленной вкладке ---
function listPageHTML(title, subject, items){
  const rows = items.map((it,i)=>{
    const val = it.link
      ? `<a href="${esc(it.link)}" target="_blank" rel="noopener">${esc(it.value)}</a>`
      : esc(it.value);
    const rel = it.rel ? `<span class="rel">${esc(it.rel)}</span>` : "";
    return `<li data-s="${esc(it.value.toLowerCase())}"><span class="num">${i+1}</span><span class="val">${val}</span>${rel}</li>`;
  }).join("");
  const close = "<"+"/script>";
  return `<!doctype html><html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)} — ${esc(subject)}</title>
<style>
  body{margin:0;font-family:Calibri,"Segoe UI",system-ui,sans-serif;color:#13293D;background:#F4F7FA}
  header{background:#0B2545;color:#fff;padding:18px 24px}
  header h1{margin:0;font-size:20px}
  header p{margin:6px 0 0;color:#D9ECF5;font-size:14px}
  .wrap{max-width:900px;margin:0 auto;padding:18px 24px}
  input{width:100%;font:inherit;font-size:15px;padding:10px 12px;border:1px solid #CFE0EC;border-radius:10px;margin-bottom:14px}
  ol{list-style:none;margin:0;padding:0}
  li{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid #E1E8F0;border-radius:10px;
     padding:10px 14px;margin-bottom:8px}
  .num{color:#9DB2C6;font-size:13px;min-width:34px}
  .val{flex:1;word-break:break-all;font-size:15px}
  .val a{color:#1C6B8C;text-decoration:none}
  .val a:hover{text-decoration:underline}
  .rel{color:#5C7A99;font-size:12px}
  .count{color:#5C7A99;font-size:13px;margin-bottom:10px}
</style></head><body>
<header><h1>${esc(title)}</h1><p>Объект: <b>${esc(subject)}</b> · всего: ${items.length}</p></header>
<div class="wrap">
  <input id="f" placeholder="фильтр по списку…" autocomplete="off">
  <div class="count" id="c">Показано: ${items.length}</div>
  <ol id="list">${rows}</ol>
</div>
<script>
var f=document.getElementById("f"),items=document.querySelectorAll("#list li"),c=document.getElementById("c");
f.addEventListener("input",function(){var q=this.value.trim().toLowerCase(),n=0;
  items.forEach(function(li){var ok=li.getAttribute("data-s").indexOf(q)>-1;li.style.display=ok?"":"none";if(ok)n++;});
  c.textContent="Показано: "+n;});
${close}
</body></html>`;
}
function openHTMLTab(htmlStr){
  var w;
  try { w = window.open("", "_blank"); } catch(e) { w = null; }
  if (w) { w.document.open(); w.document.write(htmlStr); w.document.close(); return; }
  // запасной вариант — оверлей с iframe, если браузер заблокировал новую вкладку
  var ov = document.createElement("div");
  ov.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:50;display:flex;flex-direction:column";
  var bar = document.createElement("div");
  bar.style.cssText = "background:#0B2545;color:#fff;padding:8px 14px;text-align:right;font:14px sans-serif;cursor:pointer";
  bar.textContent = "× закрыть";
  bar.onclick = function(){ ov.remove(); };
  var fr = document.createElement("iframe");
  fr.style.cssText = "flex:1;border:0;background:#fff";
  fr.srcdoc = htmlStr;
  ov.appendChild(bar); ov.appendChild(fr); document.body.appendChild(ov);
}
function openList(key){
  var ci = catInfo[key], members = catMembers[key];
  var items = members.map(function(id){
    var nd = N[id], link = null;
    if (/^https?:\/\//.test(nd.full)) link = nd.full;
    else if (nd.type === "Domain") link = "https://" + nd.full;
    return { value: nd.full, link: link, rel: nd.rel };
  });
  items.sort(function(a,b){ return a.value.localeCompare(b.value); });
  var title = (CAT_LABEL[ci.type] || ci.type);
  openHTMLTab(listPageHTML(title, N[ROOT].full, items));
}
function showPanel(m){
  const body = document.getElementById("pbody");
  let link = "";
  const isUrl = /^https?:\/\//.test(m.full) || /\.[a-z]{2,}$/i.test(m.full) && m.type==="Domain";
  if (/^https?:\/\//.test(m.full)) link = `<div class="k">Ссылка</div><div class="v"><a href="${esc(m.full)}" target="_blank" rel="noopener">Открыть →</a></div>`;
  else if (m.type==="Domain") link = `<div class="k">Сайт</div><div class="v"><a href="https://${esc(m.full)}" target="_blank" rel="noopener">${esc(m.full)} →</a></div>`;
  else if (m.type==="Location"){ const c=m.full; link = `<div class="k">На карте</div><div class="v"><a href="https://www.google.com/maps?q=${esc(c)}" target="_blank" rel="noopener">Открыть карту →</a></div>`; }
  body.innerHTML = `<h3>${esc(m.label)}</h3><div class="k">Тип</div><div class="v">${esc(m.type)}</div>`
    + (m.rel?`<div class="k">Связь</div><div class="v">${esc(m.rel)}</div>`:"")
    + `<div class="k">Значение</div><div class="v">${esc(m.full)}</div>` + link;
  document.getElementById("panel").style.display = "block";
}
document.getElementById("pclose").onclick = () => document.getElementById("panel").style.display="none";
document.getElementById("fit").onclick = fit;

// пан/зум
const stage = document.getElementById("stage");
let drag=null;
stage.addEventListener("mousedown", e=>{ drag={x:e.clientX,y:e.clientY,tx:view.tx,ty:view.ty}; stage.classList.add("drag"); });
window.addEventListener("mousemove", e=>{ if(!drag)return; view.tx=drag.tx+(e.clientX-drag.x); view.ty=drag.ty+(e.clientY-drag.y); applyView(); });
window.addEventListener("mouseup", ()=>{ drag=null; stage.classList.remove("drag"); });
stage.addEventListener("wheel", e=>{
  e.preventDefault();
  const r=stage.getBoundingClientRect(), mx=e.clientX-r.left, my=e.clientY-r.top;
  const f=e.deltaY<0?1.12:1/1.12, ns=Math.max(0.1,Math.min(4,view.s*f));
  view.tx = mx-(mx-view.tx)*(ns/view.s); view.ty = my-(my-view.ty)*(ns/view.s); view.s=ns; applyView();
}, {passive:false});

// легенда
(function(){
  const used=[...new Set(N.map(n=>n.type))].filter(t=>t!=="Missing");
  document.getElementById("legend").innerHTML = used.map(t=>`<span><i style="background:${color(t)}"></i>${t}</span>`).join("");
})();

render(); fit();
</script>
</body></html>"""


if __name__ == "__main__":
    import argparse
    from maltego_export import build_graph_edges

    parser = argparse.ArgumentParser(description="Собрать интерактивный граф в HTML")
    parser.add_argument("--out", default="graph.html")
    parser.add_argument("--subject", default="ivan_petrov")
    args = parser.parse_args()

    edges = build_graph_edges(
        subject_value=args.subject, subject_type="Alias",
        exif_data={"has_exif": True, "file": "photo.jpg", "make": "Apple", "model": "iPhone 13 Pro",
                   "software": "17.4.1", "author": "Ivan Petrov", "datetime_original": "2026:03:14 12:31:09",
                   "gps": {"lat": 55.751244, "lon": 37.618423,
                           "maps_url": "https://www.google.com/maps?q=55.751244,37.618423"}},
        sherlock_results=[{"username": args.subject, "site": "GitHub", "url": f"https://github.com/{args.subject}"},
                          {"username": args.subject, "site": "Reddit", "url": f"https://reddit.com/user/{args.subject}"}],
        email="ivan@example.com",
        holehe_results=[{"site": "twitter.com", "info": ""}, {"site": "spotify.com", "info": ""}],
        hibp_result={"email": "ivan@example.com", "mode": "api", "breached": True,
                     "breaches": [{"name": "LinkedIn", "date": "2012-05-05"}]},
    )
    path = export_html(edges, args.out, root_value=args.subject, root_type="Alias")
    print(f"Граф сохранён: {path}")
