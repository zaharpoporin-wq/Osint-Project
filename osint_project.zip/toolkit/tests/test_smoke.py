"""
test_smoke.py
===============

Простые дымовые тесты ("работает / не падает") для всей обвязки.
Запуск: pytest -v  (из папки toolkit/)

Эти тесты НЕ ходят в интернет и не требуют Sherlock — они проверяют
только нашу логику (парсинг, сбор отчёта, экспорт в CSV).
"""

import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from exif_contract import extract_exif
from hibp_helper import check_email
from maltego_export import build_graph_edges, build_rows, export_csv, export_graph_csv
from sherlock_runner import parse_sherlock_csv
from spiderfoot_runner import normalize_target, parse_spiderfoot_json

FIXTURES = Path(__file__).resolve().parent.parent


def test_exif_with_gps():
    data = extract_exif(FIXTURES / "test_photo.jpg")
    assert data["has_exif"] is True
    assert data["make"] == "Apple"
    assert data["gps"] is not None
    assert abs(data["gps"]["lat"] - 55.751244) < 1e-4


def test_exif_date_taken_from_exif_subifd():
    # В test_photo.jpg, как у настоящего телефона, DateTime (дата изменения,
    # 18:02:44) лежит в IFD0, а DateTimeOriginal (дата съёмки, 12:31:09) —
    # в Exif sub-IFD. Нам нужна именно дата съёмки.
    data = extract_exif(FIXTURES / "test_photo.jpg")
    assert data["datetime_original"] == "2026:03:14 12:31:09"
    assert data["author"] == "Ivan Petrov"
    assert data["lens"] is not None


def test_spiderfoot_json_parsing_including_cut_off_output():
    full = (
        '[{"generated": 1, "type": "ROOT", "data": "x", "module": "", "source": ""},\n'
        '{"generated": 1, "type": "Email Address", "data": "a@b.c", "module": "sfp_email", "source": "x"},\n'
        '{"generated": 1, "type": "Human Name", "data": "Ivan Petrov", "module": "sfp_names", "source": "x"}]\n'
    )
    events = parse_spiderfoot_json(full)
    assert [e["type"] for e in events] == ["Email Address", "Human Name"]  # ROOT отфильтрован

    cut = full[: full.index("Human Name") - 5]  # вывод оборвался по таймауту
    assert len(parse_spiderfoot_json(cut)) == 1


def test_spiderfoot_target_normalization():
    assert normalize_target("ivan_petrov") == '"ivan_petrov"'
    assert normalize_target("Ivan Petrov") == '"Ivan Petrov"'
    assert normalize_target("ivan@example.com") == "ivan@example.com"
    assert normalize_target("example.com") == "example.com"


def test_holehe_parsing_and_graph_edges():
    from holehe_runner import parse_holehe_output

    sample = (
        "*********************\n   test@example.com\n*********************\n"
        "[+] twitter.com te****@gmail.com\n"
        "[+] spotify.com\n"
        "[-] github.com\n"
        "[x] somehost.com\n"
        "\n120 websites checked in 8.3 seconds\n"
    )
    used = parse_holehe_output(sample)
    assert [u["site"] for u in used] == ["twitter.com", "spotify.com"]  # [-] и [x] отброшены
    assert used[0]["info"] == "te****@gmail.com"

    # в графе: почта -> сайты регистрации
    edges = build_graph_edges("zachura", "Alias",
        email="zachura@mail.ru",
        holehe_results=[{"site": "twitter.com", "info": ""}])
    assert any(e["parent_value"] == "zachura@mail.ru" and e["child_value"] == "twitter.com"
               for e in edges)


def test_exif_without_data():
    data = extract_exif(FIXTURES / "no_exif.jpg")
    assert data["has_exif"] is False
    assert data["gps"] is None


def test_hibp_manual_mode_has_no_network_call():
    # Без api_key функция не должна пытаться куда-то стучаться —
    # просто формирует ссылку для ручной проверки.
    result = check_email("test@example.com")
    assert result["mode"] == "manual"
    assert result["breached"] is None
    assert "haveibeenpwned.com/account" in result["manual_check_url"]


def test_sherlock_csv_parsing(tmp_path):
    csv_path = tmp_path / "demo.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["username", "name", "url_main", "url_user", "exists", "http_status", "response_time_s"])
        writer.writerow(["demo", "GitHub", "https://github.com", "https://github.com/demo", "Claimed", "200", "0.5"])
        writer.writerow(["demo", "SomeSite", "https://somesite.com", "https://somesite.com/demo", "Available", "404", "0.3"])

    found = parse_sherlock_csv(csv_path)
    assert len(found) == 1
    assert found[0]["site"] == "GitHub"


def test_maltego_export_roundtrip(tmp_path):
    rows = build_rows(
        exif_data=extract_exif(FIXTURES / "test_photo.jpg"),
        sherlock_results=[{"username": "demo", "site": "GitHub", "url": "https://github.com/demo", "http_status": "200"}],
        hibp_result=check_email("demo@example.com"),
    )
    assert len(rows) >= 3

    out_path = export_csv(rows, tmp_path / "out.csv")
    with out_path.open(encoding="utf-8") as f:
        lines = f.readlines()
    assert len(lines) == len(rows) + 1  # + заголовок


def test_graph_shows_missing_exif_explicitly():
    # Фото без метаданных: в графе должен быть узел «отсутствует», а не пусто
    no_exif = {"file": "selfie.png", "has_exif": False}
    edges = build_graph_edges("ivan", "Alias", exif_data=no_exif)
    assert any(e["child_value"] == "selfie.png" for e in edges)                 # фото показано
    assert any(e["child_type"] == "Missing" for e in edges)                     # и помечено «отсутствует»

    # Фото с EXIF, но без GPS: GPS показан как «отсутствует»
    partial = {"file": "p.jpg", "has_exif": True, "make": "Apple", "model": "iPhone 12",
               "datetime_original": "2026:01:01 00:00:00", "gps": None}
    edges2 = build_graph_edges("ivan", "Alias", exif_data=partial)
    labels = {e["child_value"] for e in edges2}
    assert "Apple iPhone 12" in labels                       # устройство есть
    assert any("GPS" in v and "отсут" in v for v in labels)  # а GPS явно отсутствует


def test_maltego_graph_edges(tmp_path):
    # Граф: центральный узел + рёбра к находкам, почта → утечка
    edges = build_graph_edges(
        subject_value="ivan_petrov",
        subject_type="Alias",
        exif_data=extract_exif(FIXTURES / "test_photo.jpg"),
        sherlock_results=[{"username": "ivan_petrov", "site": "GitHub", "url": "https://github.com/ivan_petrov"}],
        hibp_result={"email": "ivan@example.com", "mode": "api", "breached": True,
                     "breaches": [{"name": "LinkedIn", "date": "2012-05-05"}]},
    )
    # есть ребро от объекта к профилю и от почты к утечке
    assert any(e["parent_value"] == "ivan_petrov" and "github.com" in e["child_value"] for e in edges)
    assert any(e["parent_value"] == "ivan@example.com" and e["child_value"].startswith("Утечка") for e in edges)

    out_path = export_graph_csv(edges, tmp_path / "graph.csv")
    with out_path.open(encoding="utf-8") as f:
        header = f.readline().strip()
    assert header == "parent_value,parent_type,child_value,child_type,note"


def test_mtgx_is_valid_zip_with_wellformed_xml(tmp_path):
    import zipfile
    import xml.dom.minidom as minidom
    from maltego_graph import export_mtgx

    edges = build_graph_edges(
        subject_value="ivan_petrov", subject_type="Alias",
        exif_data=extract_exif(FIXTURES / "test_photo.jpg"),
        sherlock_results=[{"username": "ivan_petrov", "site": "GitHub", "url": "https://github.com/ivan_petrov"}],
        hibp_result={"email": "ivan@example.com", "mode": "api", "breached": True,
                     "breaches": [{"name": "LinkedIn", "date": "2012-05-05"}]},
    )
    out = export_mtgx(edges, tmp_path / "g.mtgx")
    assert out.suffix == ".mtgx"
    z = zipfile.ZipFile(out)
    assert "Graphs/Graph1.graphml" in z.namelist()
    xml = z.read("Graphs/Graph1.graphml").decode()
    minidom.parseString(xml)  # бросит исключение, если XML битый
    assert "<node " in xml and "<edge " in xml


def test_html_graph_is_dynamic(tmp_path):
    # Разные входные данные -> разные графы (не заглушка)
    from graph_html import export_html

    e1 = build_graph_edges("alex_99", "Alias",
        sherlock_results=[{"username": "alex_99", "site": "GitHub", "url": "https://github.com/alex_99"}])
    e2 = build_graph_edges("maria_k", "Alias",
        hibp_result={"email": "maria@mail.ru", "mode": "manual",
                     "manual_check_url": "https://haveibeenpwned.com/account/x"})

    h1 = export_html(e1, tmp_path / "a.html", "alex_99").read_text(encoding="utf-8")
    h2 = export_html(e2, tmp_path / "b.html", "maria_k").read_text(encoding="utf-8")

    assert "alex_99" in h1 and "github.com/alex_99" in h1
    assert "maria_k" in h2 and "maria@mail.ru" in h2
    assert h1 != h2                     # графы разные
    assert "alex_99" not in h2          # данные одного не протекают в другой
